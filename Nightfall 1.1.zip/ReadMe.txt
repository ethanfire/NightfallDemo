
README.TXT

I. BUILD FILES
- Fiore_M15_Gold.zip\
MonoBleedingEdge (folder)
Nightfall_Data (folder)
Nightfall.exe (executable)
UnityCrashHandler64.exe (executable)
UnityPlayer.dll

II. CONTROLS
-MOVEMENT:
WASD Arrow Keys

-DIALOGUE:
Initiate - walk near an NPC
Progress - E

-INTERACT (used near campfires to progress to next level once complete)
E Key

-ATTACK
Sword - Left Click
Fireball - Right Click (Not unlocked until after the first night)
	*fireballs can be shot diagonally if player moves diagonally

-LEVEL SELECT
Click on the sword in the stone on the menu screen to open up a level select menu.

III. KNOWN ISSUES AND WORKAROUNDS (if applicable)
- ISSUE 01: In the credits, "dafont.com" appears slightly cutoff.

- ISSUE 02: Fireballs are launched in the direction the player is facing by storing
	the direction the player last moved. However, at the start of the level,
	the player has yet to move! Not to worry though, shooting a fireball will
	only cause it to fizzle out where you stand. It does look a little unusual though
	and must be addressed as an issue. After the player takes their first steps,
	the issue resolves itself

IV. EASY MODE [REMOVED]
-Stored in the zip file is a folder called "Easy Mode". This is a carbon copy of the regular
	game file, only the enemy spawns are made easier each level. Everything else, including
	the rest of the bullet points, are exactly the same.

V. HIDDEN LEVELS EXPLANATION
-The game appears to have 3 levels but actually has 6 levels. This is due to the fact that
	the game has two different endings, a good ending (if the player never dies),
	and a bad ending (if the player dies, but makes a deal with a certain suspicious
	character to come back and keep fighting). 

-If the player ever dies, and then they make a deal with the skeleton in the void to 
	come back to life, they will receive double health and double sword attack damage. 
	This is to balance the game for people who cannot complete the regular difficulty.

-Once you come back, though, the player's ending will be tainted, and they will be on the
	level track that leads them to the bad ending. ANY level leading to a bad ending can
	be denoted by the music (it will be at a slower pitch than the regular ending levels).

-Taking a zoomed out look, there are levels 1, 2, 3, and also levels 1d, 2d, and 3d.
	If you die on levels 1, 2, or 3, and choose to come back to life, you will be placed in
	the corresponding death ("d") level. For example, if I died on level 2, and came back to life,
	I would be placed in level 2d.

VI. LEVEL DIAGRAM

Regular
Menu      ----->   Level 1     ------->     Level 2     ------->      Level 3     ------->   Happy Ending

		      |	    	               |	     	         |
		      |                        |                         |
Tainted  ---->  If player resurrects     If player resurrects      If player resurrects    
Menu		      |                        |                         |
		      |			       |			 |
                      V			       V			 V

                  Level 1d     ------->     Level 2d     ------->     Level 3d      ------->    Bad Ending

					 |
					 |
			if player dies AGAIN after second chance
			|				     |
		if player quits fairly			if player tries to cheat death
			|				     |
			V				     V

		Regular Menu				Tainted Menu*


*The only difference between the regular menu and the tained menu is that the regular menu's LEVEL SELECT
	will take the player to the good ending levels, but the tainted menu will place the player
	on the respective "d" level. Like the other "d" levels, the tainted menu can also be denoted
	by it's lower pitched music.